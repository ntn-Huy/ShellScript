#Viết đoạn Script lưu trữ thời điểm đăng nhập Linux hàng ngày và lưu lịch sử vào
#file txt với format sau:
#Giờ-Phút-Giây-Ngày-Tháng-Năm-Tên User 

#Dinh dang thoi gian
time=$(date +"%H-%M-%S-%d-%m-%Y")

#Lay ten user cua may
user=$USER
echo "Dang tao file login_history....."
#luu vao file log.txt
log="$HOME/login_history.txt"

#Ghi thong tin vao file log.txt
echo "$time-$user" >> "$log" >> ~/.bashrc

echo "Hoan tat!"
